# roads > 2024-09-15 11:39am
https://universe.roboflow.com/imagesegmentation-5fcdp/roads-1bztp

Provided by a Roboflow user
License: CC BY 4.0

