# roads > 2024-11-15 7:52pm
https://universe.roboflow.com/imagesegmentation-5fcdp/roads-1bztp

Provided by a Roboflow user
License: CC BY 4.0

