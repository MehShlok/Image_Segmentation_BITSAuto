# Lanenet dataset > 2024-09-10 7:50am
https://universe.roboflow.com/sankabapur/lanenet-dataset

Provided by a Roboflow user
License: CC BY 4.0

