# Roads > 2024-09-15 6:10pm
https://universe.roboflow.com/campusroads/roads-4mmxz

Provided by a Roboflow user
License: CC BY 4.0

